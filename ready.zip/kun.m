%Breytum pend�l fallinu t�kum �t alla teikniskipanir og � sta�inn skilar
%�etta fall loka gildinu sem falli� tekur s.s t=1 ef inter=[0 1]. 
function A=kun(inter,ic,n)
h=(inter(2)-inter(1))/n; % plot n points in total
y(1,:)=ic;                % enter initial conds in y
t(1)=inter(1);

  
for k=1:n
  t(k+1)=t(k)+h;
  y(k+1,:)=kunstep(t(k),y(k,:),h);

end
A=y(n+1,:);
F=y;

function y = kunstep(t,x,h)
%one step of the Runge-kutta method
k1=ydot(t,x);
k2=ydot(t+h/2,x+h/2*k1);
k3=ydot(t+h/2,x+h/2*k2);
k4=ydot(t+h,x+h*k3);

y=x+(h/6)*(k1+2*k2+2*k3+k4);
function z=ydot(t,y)
g=9.81;
length=1;
a = y(1)-y(3); 
z(1) = y(2); 
z(2) = -3*g*sin(y(1))-g*sin(y(1)-2*y(3))-2*sin(a)*(y(4)^2-y(2)^2*cos(a)); 
z(2) = z(2)/(3-cos(2*a)); 
z(3) = y(4); 
z(4) = (2*sin(a)*(2*y(2)^2+2*g*cos(y(1))+y(4)^2*cos(a)))/(3-cos(2*a));