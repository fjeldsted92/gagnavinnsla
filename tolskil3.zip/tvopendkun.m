%a�lag� pend�ls fall �ar sem b�i� er a� b�ta vi� ��rum pend�l 
% ic er upphafsskilyr�i pend�ls nr1.
% ic + dh er upphafsskylyr�i pend�ls nr2.
function tvopendkun(inter,ic,n,dh)
h=(inter(2)-inter(1))/n; % plot n points in total
y(1,:)=ic; % enter initial conds in y
y2(1,:)=ic+dh;  % upphaf skilyr�i fyrir pend�l 2
t(1)=inter(1);
set(gca,'xlim',[-2.2 2.2],'ylim',[-2.2 2.2], ...
  'XTick',[-2 0 2],'YTick',[-2 0 2], ...
  'Drawmode','fast','Visible','on','NextPlot','add');
cla;                     
axis square               % make aspect ratio 1 - 1
bob = line('color','r','Marker','.','markersize',40,...
    'erase','xor','xdata',[],'ydata',[]);
rod = line('color','b','LineStyle','-','LineWidth',3,...
    'erase','xor','xdata',[],'ydata',[]);
  bob2 = line('color','g','Marker','.','markersize',40,'erase','xor','xdata',[],'ydata',[]);
  rod2 = line('color','b','LineStyle','-','LineWidth',3,'erase','xor','xdata',[],'ydata',[]);
bob3 = line('color','r','Marker','.','markersize',40,...
    'erase','xor','xdata',[],'ydata',[]);
rod3 = line('color','y','LineStyle','-','LineWidth',3,...
    'erase','xor','xdata',[],'ydata',[]);
  bob4 = line('color','g','Marker','.','markersize',40,'erase','xor','xdata',[],'ydata',[]);
  rod4 = line('color','y','LineStyle','-','LineWidth',3,'erase','xor','xdata',[],'ydata',[]);  
for k=1:n
  t(k+1)=t(k)+h;
  y(k+1,:)=kunstep(t(k),y(k,:),h); % Y fyrir y0 pend�l
  y2(k+1,:)=kunstep(t(k),y2(k,:),h); % Y fyrir Y0+dh pend�l
  xbob = sin(y(k+1,1)); ybob = -cos(y(k+1,1));
  xrod = [0 xbob]; yrod = [0 ybob];
  set(rod,'xdata',xrod,'ydata',yrod)
  set(bob,'xdata',xbob,'ydata',ybob)
  xbob2 = xbob+sin(y(k+1,3)); ybob2 = ybob-cos(y(k+1,3)); xrod2 = [xbob xbob2]; yrod2 = [ybob ybob2];
  set(rod2,'xdata',xrod2,'ydata',yrod2);
  set(bob2,'xdata',xbob2,'ydata',ybob2)
  
  xbod3 = sin(y2(k+1,1)); ybob3 = -cos(y2(k+1,1));
  xrod3 = [0 xbod3]; yrod3 = [0 ybob3];
  set(rod3,'xdata',xrod3,'ydata',yrod3)
  set(bob3,'xdata',xbod3,'ydata',ybob3)
  xbod4 = xbod3+sin(y2(k+1,3)); ybob4 = ybob3-cos(y2(k+1,3)); xrod4 = [xbod3 xbod4]; yrod4 = [ybob3 ybob4];
  set(rod4,'xdata',xrod4,'ydata',yrod4);
  set(bob4,'xdata',xbod4,'ydata',ybob4)
  drawnow; pause(h)
end

function y = kunstep(t,x,h)
%one step of the Runge-kutta method
k1=ydot(t,x);
k2=ydot(t+h/2,x+h/2*k1);
k3=ydot(t+h/2,x+h/2*k2);
k4=ydot(t+h,x+h*k3);

y=x+(h/6)*(k1+2*k2+2*k3+k4);
function z=ydot(t,y)
g=9.81;
length=1;
a = y(1)-y(3); 
z(1) = y(2); 
z(2) = -3*g*sin(y(1))-g*sin(y(1)-2*y(3))-2*sin(a)*(y(4)^2-y(2)^2*cos(a)); 
z(2) = z(2)/(3-cos(2*a)); 
z(3) = y(4); 
z(4) = (2*sin(a)*(2*y(2)^2+2*g*cos(y(1))+y(4)^2*cos(a)))/(3-cos(2*a));