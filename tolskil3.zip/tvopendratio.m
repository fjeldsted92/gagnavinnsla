%sama fall og fyrir tvo tv�falda pend�la bara b�i� a� henda �llum 
% teikni skipunum og breyta fallinu �annig a� �a� skili A =norm(y-y2)/norm(y)
function [y,y2]=tvopendratio(inter,ic,n,dh)
h=(inter(2)-inter(1))/n; % plot n points in total
y(1,:)=ic; % enter initial conds in y
y2(1,:)=ic+dh;  % upphaf skilyr�i fyrir pend�l 2
t(1)=inter(1);

for k=1:n
  t(k+1)=t(k)+h;
  y(k+1,:)=kunstep(t(k),y(k,:),h);
  y2(k+1,:)=kunstep(t(k),y2(k,:),h);
end

function y = kunstep(t,x,h)
%one step of the Runge-kutta method
k1=ydot(t,x);
k2=ydot(t+h/2,x+h/2*k1);
k3=ydot(t+h/2,x+h/2*k2);
k4=ydot(t+h,x+h*k3);

y=x+(h/6)*(k1+2*k2+2*k3+k4);
function z=ydot(t,y)
g=9.81;
length=1;
a = y(1)-y(3); 
z(1) = y(2); 
z(2) = -3*g*sin(y(1))-g*sin(y(1)-2*y(3))-2*sin(a)*(y(4)^2-y(2)^2*cos(a)); 
z(2) = z(2)/(3-cos(2*a)); 
z(3) = y(4); 
z(4) = (2*sin(a)*(2*y(2)^2+2*g*cos(y(1))+y(4)^2*cos(a)))/(3-cos(2*a));