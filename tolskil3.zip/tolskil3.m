
pendkun([0 10],[pi/2,0,-pi/2,0],1000); 
%%
%%li�ur 3 
%reiknum vi�fermu skekkjuna fyrir t=10
%h=(tfinal-t0)/n   h=10*-3  => 1/n =10^-3  -> n=10000 

n=10000;

%reiknum T10 fyrir h=1/1000 og h=1/2000 
R1=kun([0 10],[pi/2,0,-pi/2,0],n);  %
R2=kun([0 10],[pi/2,0,-pi/2,0],n*2);%
Err10=norm(R2-R1);
display('Skekkjan mi�a� vi� n�lgun � vinnuse�li fyrir h=1*10^-3');
display(Err10);

%%
w1=zeros(6,4);
%finnum n� t=1 fyrir h=1*10^(-3), n=1000 og notum n�lgun �r vinnuse�li til a� sko�a hverning skekkjan �r�ast.

n=1000;
for i=1:6 %reiknum ti=1 �ar sem h er helminga� � hveri �trun.
    z=kun([0 1],[pi/2,0,-pi/2,0],n);
    n=n*2;
    w1(i,1)=z(1); w1(i,2)=z(2);w1(i,3)=z(3);w1(i,4)=z(4);
end
Err1=zeros(5,1);
h=zeros(5,1);
tmp=1*10^(-3);
for i=1:5  %��tlum skekkjuna me� n�lgun �r vinnuse�li fyrir reiknu� gildi � fyrri forlykkju og t�kum logarmithman af skekkjuni
    h(i)=log(tmp);
    tmp=tmp/2;
    Err1(i)=norm(w1(i+1)-w1(i)); 
    Err1(i)=log(Err1(i));
end
    coeff=polyfit(h,Err1,1); % notum polyfit til a� finna hallt�lu bestul�nu � gegnum punktasafni� 
    Y=coeff(1).*h+coeff(2);
    figure
    plot(h,Err1,'*',h,Y);
    title('ti=1 logarithminn af h og v��fermuskekkjuni')
    xlabel('log(h)');
    ylabel('log(e(t1,h)');
    legend(['gagnapunktar','Bestal�na']);
    % sj�um a� hallatalan er n�l�gt 4 sem passar vi� a� v��fermi
    % villuli�urinn s� h^4*(f(ti,h))  �st��an fyrir �v� a� vi� sleppum
    % s��asta punktinum er a� �ar er skekkjan vegna fj�lda aukastafa sem
    % t�lvan getur reikna� me� farinn a� hafa veruleg �hrif.
    %% li�ur 4 
    %b�i� a�  b�a til n�tt pend�ls fall fyrir tv�faldan pend�l. 
    figure
    tvopendkun([0 10], [pi/2 0 -pi/2 0], 1000, [1/1000 1/1000 1/1000 1/1000]);
    %
    %%
    [Ya,Yb]=tvopendratio([0 10], [pi/2 0 -pi/2 0], 2000, [1/1000 1/1000 1/1000 1/1000]);
    B=linspace(0,10, 2001);
   
       Ratio01=abs((Ya(:,1)-Yb(:,1)));
       Ratio02=abs((Ya(:,2)-Yb(:,2)));
       Ratio03=abs((Ya(:,3)-Yb(:,3)));
       Ratio04=abs((Ya(:,4)-Yb(:,4)));
    
    figure 
    title('�r�un mismunar(Ya-Yb)')
    subplot(2,2,1);
    plot(B,Ratio01);
    
    title('Y1');
    xlabel('t�mi');
    ylabel('mismunar');
    
    subplot(2,2,2);
    plot(B,Ratio02);
    
    title('Y2');
    xlabel('t�mi');
    ylabel('mismunar');
    
    subplot(2,2,3);
    plot(B,Ratio03);
    
    title('Y3');
    xlabel('t�mi');
    ylabel('mismunar');
    
    subplot(2,2,4);
    plot(B,Ratio04);
    
    title('Y4');
    xlabel('t�mi');
    ylabel('mismunar');
    % �essi missmunur kemur af einhvejrum hluta til vegna
    % v��fermuskekkjunar en �a� m� ekki gleyma a� veri� er a� leysa tv�
    % missmunandi upphafsgildisverkefni sem gefa tv�r missmunandi lausnir, 
    % V�sa m� til myndbands sem Ingunn s�ndi � t�ma �ar sem �rl�till munur 
    % � upphafst��u pend�ls leiddi til mikills mun � sveiflum.
    % hlutfalli� er st��ugt vaxdandi � bilinu en �a� koma topar inn
    % � milli hlj�ta a� orsakast vegna mismunandi heg�unar vegna �essa
    % litla mun � upphafsgilid.